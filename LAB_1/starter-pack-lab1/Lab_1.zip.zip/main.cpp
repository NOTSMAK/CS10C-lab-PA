#include <iostream>

#include "Playlist.h"

using namespace std;

int main() {
  // REMOVE: The zybook wants you to hold onto the playlist title in
  // REMOVE: main.  I would have liked it as a member of the Playlist
  // REMOVE: but please follow the Zybook Lab prompt here
  string title;
  cout << "Enter playlist's title:" << endl << endl;
  getline(cin,title);

  // Build a playlist which we will use to execute the commands
  // in the loop below
  Playlist P;
  string command;
  while(command != "q") {
    P.PrintMenu(title);
    cin>> command;
    // Read commands until error or end-of-file
    // It is much better to read a string here than a character
    // because it will read a single "chunk" of characters and
    // we don't have to deal with problems reading a character
    // without a newline, or when we make a mistake and don't
    // prompt for something that we needed.
   

    // We support seven commands.  The Lab prompt says only
    // to prompt again on error... so we don't output any message
    // on a bad command
    if (command == "a") {
      string songID;
      string songName;
      string artistName;
      int songLength;
      cout << endl << "ADD SONG" << endl;
      cout << "Enter song's unique ID:" << endl;
      cin >> songID;
      cin.ignore();
     cout << "Enter song's name:" << endl;
     getline(cin, songName);
      cout << "Enter artist's name:"<< endl;
      getline(cin, artistName);
      cout << "Enter song's length (in seconds):" << endl << endl;
      cin >> songLength;
      
      P.AddSong(songID,songName,artistName,songLength);
    } if (command == "d") {
      cout << "REMOVE SONG" << endl;
      P.RemoveSong();
    }  if (command == "c") {
      cout << "CHANGE POSITION OF SONG" << endl;
      P.ChangePositionSong();
    }  if (command == "s") {
      cout << "OUTPUT SONGS BY SPECIFIC ARTIST" << endl;
      P.OutputSongsByArtist();
    }  if (command == "t") {
      cout << "OUTPUT TOTAL TIME OF PLAYLIST (IN SECONDS)" << endl;
      P.OutputTotalTime();
    }  if (command == "o") {
      cout << title << " - OUTPUT FULL PLAYLIST" ;
      P.OutputFullPlaylist();
    }  
  }

  // If cin is in an error state (even end-of-file), then
  // something went wrong
  if (!cin) {
    cout << "Program did not exit cleanly" << endl;
    return 1;
  }
  
  return 0;
}
